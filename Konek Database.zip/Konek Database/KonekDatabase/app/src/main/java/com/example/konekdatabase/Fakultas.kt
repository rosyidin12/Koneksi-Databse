package com.example.konekdatabase

data class Fakultas (val id_fakultas:Int?, val kode_fakultas:String?, val nama_fakultas:String?)